number num = 3;
string str = "hello";
function main()
{
    if(str == 3) {
        print("compare");
    }

    num = "hello"; 
}
