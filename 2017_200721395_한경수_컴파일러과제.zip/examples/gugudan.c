
function main()
{
    i=2;

    for(i=2; i<10; i=i+1)
    {
        for(j=1;j<10;j=j+1)
        {
            k=i*j;
            print(i);
            print("*");
            print(j);
            print("=");
            print(k);
            print("\t");
        }
        print("\n");
    }
}
